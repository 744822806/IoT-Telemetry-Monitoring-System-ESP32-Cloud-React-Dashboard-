import mongoose from "mongoose";

const readingSchema = new mongoose.Schema(
  {
    deviceId: String,
    temperature: Number,
    timestamp: Date,
  },
  { timestamps: true }
);

export default mongoose.model("Reading", readingSchema);
