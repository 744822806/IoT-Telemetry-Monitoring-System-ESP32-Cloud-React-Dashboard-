import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import http from "http";
import { Server as SocketIOServer } from "socket.io";
import readingsRouter from "./routes/readings.js";

const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());

// Attach socket.io to all requests
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Routes
app.use("/api/readings", readingsRouter);

// ======= 🌎 MongoDB Atlas Online Database =======
const MONGO_URI =
  "mongodb+srv://esp32user:Esp32project123@esp32cluster0.o5edrs1.mongodb.net/iot_temp?retryWrites=true&w=majority&appName=ESP32Cluster0";

const PORT = 4000;

// Connect to MongoDB Atlas
mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("🌎 Connected to MongoDB Atlas");
    server.listen(PORT, () => {
      console.log(`🚀 Server running at http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB Atlas connection error:", err);
  });

// WebSocket connection
io.on("connection", (socket) => {
  console.log("🔌 Web client connected");
});
