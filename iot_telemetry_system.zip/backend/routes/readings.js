import express from "express";
import Reading from "../models/Reading.js";

const router = express.Router();

// 接收 ESP32 的温度数据（POST）
router.post("/", async (req, res) => {
  try {
    const { temperature, timestamp, deviceId } = req.body;

    console.log("ESP32 sent:", req.body);

    // 保存到数据库
    const doc = await Reading.create({
      deviceId,
      temperature,
      timestamp: new Date(timestamp),
    });

    // 推送到 Web 前端（实时）
    req.io.emit("new-reading", {
      deviceId,
      temperature,
      timestamp: doc.timestamp,
    });

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false });
  }
});

router.get("/latest", async (req, res) => {
  const latest = await Reading.findOne().sort({ timestamp: -1 });
  res.json(latest);
});

export default router;
