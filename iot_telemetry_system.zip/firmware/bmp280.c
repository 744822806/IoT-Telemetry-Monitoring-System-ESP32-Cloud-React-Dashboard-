#include "bmp280.h"
#include "driver/i2c.h"
#include "esp_log.h"

#define I2C_SDA 21
#define I2C_SCL 22
#define I2C_PORT I2C_NUM_0
#define BMP280_ADDR 0x76

static uint16_t dig_T1;
static int16_t dig_T2, dig_T3;
static int32_t t_fine;

static uint8_t read_reg(uint8_t reg)
{
    uint8_t data;
    i2c_master_write_read_device(I2C_PORT, BMP280_ADDR, &reg, 1, &data, 1, 1000 / portTICK_PERIOD_MS);
    return data;
}

static void write_reg(uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = {reg, val};
    i2c_master_write_to_device(I2C_PORT, BMP280_ADDR, buf, 2, 1000 / portTICK_PERIOD_MS);
}

static void i2c_init()
{
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_SDA,
        .scl_io_num = I2C_SCL,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 100000
    };

    i2c_param_config(I2C_PORT, &conf);
    i2c_driver_install(I2C_PORT, conf.mode, 0, 0, 0);
}

void bmp280_init()
{
    i2c_init();

    dig_T1 = read_reg(0x88) | (read_reg(0x89) << 8);
    dig_T2 = read_reg(0x8A) | (read_reg(0x8B) << 8);
    dig_T3 = read_reg(0x8C) | (read_reg(0x8D) << 8);

    write_reg(0xF4, 0x27);//001 = osrs_t (temperature oversampling x1)，001 = osrs_p (pressure oversampling x1)，11  = mode   (normal mode)
}

float bmp280_read_temperature()
{
    int32_t msb = read_reg(0xFA);
    int32_t lsb = read_reg(0xFB);
    int32_t xlsb = read_reg(0xFC);

    int32_t adc_T = (msb << 12) | (lsb << 4) | (xlsb >> 4);

    int32_t var1 = ((((adc_T >> 3) - ((int32_t)dig_T1 << 1))) * dig_T2) >> 11;
    int32_t var2 = (((((adc_T >> 4) - ((int32_t)dig_T1)) *
                      ((adc_T >> 4) - ((int32_t)dig_T1))) >> 12) *
                    dig_T3) >> 14;

    t_fine = var1 + var2;
    float T = (t_fine * 5 + 128) >> 8;
    return T / 100;
}