#pragma once
#include <stdint.h>

void wifi_http_init(void);
void wifi_http_post(float temp, int64_t timestamp_ms);
