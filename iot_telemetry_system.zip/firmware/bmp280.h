#pragma once
void bmp280_init(void);
float bmp280_read_temperature(void);