#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#include "bmp280.h"
#include "wifi_http.h"
#include "esp_log.h"

typedef struct {
    float temp;
    int64_t ts;
} temp_msg_t;

static QueueHandle_t temp_queue;
static const char *TAG = "MAIN";

/* ---------------- 任务 1：读取温度，发送到队列 ---------------- */
void temperature_task(void *pv)
{
    bmp280_init();
    ESP_LOGI(TAG, "BMP280 init OK");

    while (1) {
        temp_msg_t msg;
        msg.temp = bmp280_read_temperature();
        msg.ts   = esp_timer_get_time() / 1000;

        xQueueSend(temp_queue, &msg, 0);

        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

/* ---------------- 任务 2：接收队列 → 打印 + 上传 ---------------- */
void wifi_task(void *pv)
{
    wifi_http_init();
    vTaskDelay(pdMS_TO_TICKS(2000)); // 等 WiFi

    temp_msg_t msg;
    while (1) {
        if (xQueueReceive(temp_queue, &msg, portMAX_DELAY)) {

            // 课程要求：“Console output”
            printf("Temp: %.2f C\n", msg.temp);

            // 上传到后台
            wifi_http_post(msg.temp, msg.ts);
        }
    }
}

void app_main()
{
    temp_queue = xQueueCreate(10, sizeof(temp_msg_t));

    xTaskCreate(temperature_task, "temperature_task", 4096, NULL, 5, NULL);
    xTaskCreate(wifi_task,         "wifi_task",        4096, NULL, 5, NULL);
}
