import { useEffect, useState } from "react";
import axios from "axios";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip
} from "chart.js";
import { FaTemperatureHigh } from "react-icons/fa";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip);

function App() {
  const [temperature, setTemperature] = useState(null);
  const [history, setHistory] = useState([]);

  // Fetch latest reading
  async function fetchLatest() {
    try {
      const res = await axios.get("http://localhost:4000/api/readings/latest");
      if (res.data) {
        setTemperature(res.data.temperature);

        // Append to history (last 20 points)
        setHistory((prev) => {
          const newData = [...prev, res.data.temperature];
          return newData.slice(-20);
        });
      }
    } catch (err) {
      console.error("Fetch error:", err);
    }
  }

  useEffect(() => {
    fetchLatest();
    const timer = setInterval(fetchLatest, 2000);
    return () => clearInterval(timer);
  }, []);

  const chartData = {
    labels: history.map((_, idx) => idx + 1),
    datasets: [
      {
        label: "Temperature (°C)",
        data: history,
        borderColor: "#0078ff",
        backgroundColor: "rgba(0,120,255,0.2)",
        tension: 0.3
      }
    ]
  };

  return (
    <div style={{
      fontFamily: "Inter, Arial",
      padding: "40px",
      maxWidth: "900px",
      margin: "0 auto",
      color: "#222"
    }}>
      
      {/* Header */}
      <h1 style={{ fontSize: "32px", marginBottom: "30px", fontWeight: 600 }}>
        IoT Temperature Monitoring Dashboard
      </h1>

      {/* Temperature card */}
      <div style={{
        display: "flex",
        alignItems: "center",
        background: "white",
        padding: "25px",
        borderRadius: "14px",
        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
        marginBottom: "30px"
      }}>
        <FaTemperatureHigh size={55} color="#ff5722" style={{ marginRight: "20px" }} />
        <div>
          <div style={{ fontSize: "20px", color: "#666" }}>Current Temperature</div>
          <div style={{ fontSize: "48px", fontWeight: "bold" }}>
            {temperature !== null ? `${temperature} °C` : "Loading..."}
          </div>
        </div>
      </div>

      {/* Chart card */}
      <div style={{
        background: "white",
        padding: "25px",
        borderRadius: "14px",
        boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
      }}>
        <h2 style={{ marginBottom: "20px" }}>Temperature Trend</h2>
        <Line data={chartData} />
      </div>
    </div>
  );
}

export default App;
